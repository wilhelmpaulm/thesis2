<?php

class User_calendarsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('user_calendars')->truncate();

		$user_calendars = array(

//			["id" => , "receiver_id" => , "sender_id" => , "action" => "", "details" => "", "date_start" => "", "date_end" => ""],

		);

		// Uncomment the below to run the seeder
		// DB::table('user_calendars')->insert($user_calendars);
	}

}
