<?php

class Message_recipientsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('message_recipients')->truncate();

		$message_recipients = array(

//			["id" => , "message_id" => , "user_id" =>],

		);

		// Uncomment the below to run the seeder
		// DB::table('message_recipients')->insert($message_recipients);
	}

}
