<?php

class User_notificationsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('user_notifications')->truncate();

		$user_notifications = array(

//			["id" => , "receiver_id" => , "sender_id" => , "action" => "", "details" => ""],
		);

		// Uncomment the below to run the seeder
		// DB::table('user_notifications')->insert($user_notifications);
	}

}
