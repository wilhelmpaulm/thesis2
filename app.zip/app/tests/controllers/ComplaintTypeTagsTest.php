<?php

use Mockery as m;
use Way\Tests\Factory;

class ComplaintTypeTagsTest extends TestCase {

	public function __construct()
	{
		$this->mock = m::mock('Eloquent', 'Complaint_type_tag');
		$this->collection = m::mock('Illuminate\Database\Eloquent\Collection')->shouldDeferMissing();
	}

	public function setUp()
	{
		parent::setUp();

		$this->attributes = Factory::complaint_type_tag(['id' => 1]);
		$this->app->instance('Complaint_type_tag', $this->mock);
	}

	public function tearDown()
	{
		m::close();
	}

	public function testIndex()
	{
		$this->mock->shouldReceive('all')->once()->andReturn($this->collection);
		$this->call('GET', 'complaint_type_tags');

		$this->assertViewHas('complaint_type_tags');
	}

	public function testCreate()
	{
		$this->call('GET', 'complaint_type_tags/create');

		$this->assertResponseOk();
	}

	public function testStore()
	{
		$this->mock->shouldReceive('create')->once();
		$this->validate(true);
		$this->call('POST', 'complaint_type_tags');

		$this->assertRedirectedToRoute('complaint_type_tags.index');
	}

	public function testStoreFails()
	{
		$this->mock->shouldReceive('create')->once();
		$this->validate(false);
		$this->call('POST', 'complaint_type_tags');

		$this->assertRedirectedToRoute('complaint_type_tags.create');
		$this->assertSessionHasErrors();
		$this->assertSessionHas('message');
	}

	public function testShow()
	{
		$this->mock->shouldReceive('findOrFail')
				   ->with(1)
				   ->once()
				   ->andReturn($this->attributes);

		$this->call('GET', 'complaint_type_tags/1');

		$this->assertViewHas('complaint_type_tag');
	}

	public function testEdit()
	{
		$this->collection->id = 1;
		$this->mock->shouldReceive('find')
				   ->with(1)
				   ->once()
				   ->andReturn($this->collection);

		$this->call('GET', 'complaint_type_tags/1/edit');

		$this->assertViewHas('complaint_type_tag');
	}

	public function testUpdate()
	{
		$this->mock->shouldReceive('find')
				   ->with(1)
				   ->andReturn(m::mock(['update' => true]));

		$this->validate(true);
		$this->call('PATCH', 'complaint_type_tags/1');

		$this->assertRedirectedTo('complaint_type_tags/1');
	}

	public function testUpdateFails()
	{
		$this->mock->shouldReceive('find')->with(1)->andReturn(m::mock(['update' => true]));
		$this->validate(false);
		$this->call('PATCH', 'complaint_type_tags/1');

		$this->assertRedirectedTo('complaint_type_tags/1/edit');
		$this->assertSessionHasErrors();
		$this->assertSessionHas('message');
	}

	public function testDestroy()
	{
		$this->mock->shouldReceive('find')->with(1)->andReturn(m::mock(['delete' => true]));

		$this->call('DELETE', 'complaint_type_tags/1');
	}

	protected function validate($bool)
	{
		Validator::shouldReceive('make')
				->once()
				->andReturn(m::mock(['passes' => $bool]));
	}
}
