<?php

class Form_transmitalsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('form_transmitals')->truncate();

		$form_transmitals = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('form_transmitals')->insert($form_transmitals);
	}

}
